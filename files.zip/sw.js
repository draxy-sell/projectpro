// ═══════════════════════════════════════════════
// ProjectPro — Service Worker v1.0
// Gère les notifications en arrière-plan
// ═══════════════════════════════════════════════

const SW_VERSION = 'projectpro-v1';

// ── État persisté en mémoire SW ──
let swData = {
  projects: [],
  tasks: [],
  reminders: [],
  members: [],
  fired: [],   // clés des notifs déjà envoyées
};

// ─────────────────────────────────────────────
// INSTALL & ACTIVATE
// ─────────────────────────────────────────────
self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(self.clients.claim());
});

// ─────────────────────────────────────────────
// MESSAGES depuis le tab principal
// ─────────────────────────────────────────────
self.addEventListener('message', (e) => {
  if (!e.data) return;

  if (e.data.type === 'SAVE_DATA') {
    const { projects, tasks, reminders, members, fired } = e.data.payload;
    swData.projects  = projects  || [];
    swData.tasks     = tasks     || [];
    swData.reminders = reminders || [];
    swData.members   = members   || [];
    // Fusionner les clés déjà tirées
    fired.forEach(k => { if (!swData.fired.includes(k)) swData.fired.push(k); });
    // Nettoyer si trop grand
    if (swData.fired.length > 800) swData.fired = swData.fired.slice(-400);
  }
});

// ─────────────────────────────────────────────
// PERIODIC SYNC (navigateurs compatibles)
// Déclenché par le navigateur toutes les ~1h
// ─────────────────────────────────────────────
self.addEventListener('periodicsync', (e) => {
  if (e.tag === 'check-deadlines') {
    e.waitUntil(checkAndNotify());
  }
});

// ─────────────────────────────────────────────
// NOTIFICATION CLICK
// ─────────────────────────────────────────────
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => {
      // Focus un onglet existant si possible
      for (const client of clients) {
        if ('focus' in client) return client.focus();
      }
      // Sinon ouvrir un nouvel onglet
      if (self.clients.openWindow) return self.clients.openWindow('./');
    })
  );
});

// ─────────────────────────────────────────────
// LOGIQUE DE VÉRIFICATION & ENVOI
// ─────────────────────────────────────────────
async function checkAndNotify() {
  const now       = new Date();
  const dateKey   = now.toISOString().split('T')[0];
  const heure     = now.getHours();
  const minutes   = now.getMinutes();

  // 1. Rappels ponctuels (fenêtre ±5 min autour de l'heure programmée)
  for (const r of swData.reminders) {
    if (r.done) continue;
    const dt      = new Date(r.date + 'T' + (r.time || '09:00'));
    const diffMin = (dt - now) / 60000;
    const key     = `rem_${r.id}_${r.date}_${r.time}`;
    if (diffMin >= -5 && diffMin <= 5 && !swData.fired.includes(key)) {
      swData.fired.push(key);
      const proj = swData.projects.find(p => p.id === r.project);
      const body = (proj ? `📁 ${proj.nom}\n` : '') + (r.desc || '');
      await sendNotification(
        `${r.type.split(' ')[0]} ${r.title}`,
        body.trim() || 'Rappel ProjectPro',
        r.urgency === 'Critique' || r.urgency === 'Urgent' ? 'high' : 'default',
        r.type.split(' ')[0]
      );
    }
  }

  // 2. Digest quotidien à 9h — projets & tâches proches
  if (heure !== 9 || minutes > 10) return;

  for (const p of swData.projects) {
    if (p.status === 'Terminé' || p.status === 'Annulé' || !p.end) continue;
    const dl  = daysLeft(p.end);
    if (dl === null || dl < 0 || dl > 14) continue;
    const key = `proj_${p.id}_${dateKey}`;
    if (swData.fired.includes(key)) continue;
    swData.fired.push(key);

    const prog  = getProjectProgress(p.id);
    const emoji = dl === 0 ? '🔴' : dl <= 3 ? '🔴' : dl <= 7 ? '🟡' : '🟠';
    const label = dl === 0 ? "AUJOURD'HUI" : `J-${dl}`;
    await sendNotification(
      `${emoji} ${label} — ${p.nom}`,
      `Avancement : ${prog}% · Échéance : ${formatDate(p.end)}`,
      dl <= 3 ? 'high' : 'default',
      p.icon || '📁'
    );
  }

  for (const t of swData.tasks) {
    if (t.status === 'Terminé' || !t.due) continue;
    const dl  = daysLeft(t.due);
    if (dl === null || dl < 0 || dl > 7) continue;
    const key = `task_${t.id}_${dateKey}`;
    if (swData.fired.includes(key)) continue;
    swData.fired.push(key);

    const proj  = swData.projects.find(p => p.id === t.project);
    const emoji = dl === 0 ? '🔴' : dl <= 3 ? '🔴' : '🟡';
    const label = dl === 0 ? "AUJOURD'HUI" : `J-${dl}`;
    await sendNotification(
      `${emoji} ${label} — ${t.title}`,
      (proj ? `📁 ${proj.nom} · ` : '') + `Priorité : ${t.prio} · ${formatDate(t.due)}`,
      dl <= 3 ? 'high' : 'default',
      '✅'
    );
  }
}

// ─────────────────────────────────────────────
// HELPERS (dupliqués ici car le SW est isolé)
// ─────────────────────────────────────────────
function daysLeft(d) {
  if (!d) return null;
  const diff = (new Date(d + 'T00:00:00') - new Date()) / 86400000;
  return Math.ceil(diff);
}

function formatDate(d) {
  if (!d) return '—';
  return new Date(d + 'T00:00:00').toLocaleDateString('fr-FR', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
}

function getProjectProgress(pid) {
  const pt = swData.tasks.filter(t => t.project === pid);
  if (!pt.length) return 0;
  return Math.round(pt.filter(t => t.status === 'Terminé').length / pt.length * 100);
}

async function sendNotification(title, body, urgency = 'default', iconEmoji = '🔔') {
  const svgIcon = `data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">${encodeURIComponent(iconEmoji)}</text></svg>`;
  await self.registration.showNotification(title, {
    body,
    icon: svgIcon,
    badge: svgIcon,
    tag: title,
    requireInteraction: urgency === 'high',
    vibrate: urgency === 'high' ? [200, 100, 200] : [100],
    data: { url: './' },
  });
}
